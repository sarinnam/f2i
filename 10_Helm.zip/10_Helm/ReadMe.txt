helm create endpoints

helm install --name endpoints endpoints/

1BWMlzBt34
